void setName(char* name);
void print_name();
