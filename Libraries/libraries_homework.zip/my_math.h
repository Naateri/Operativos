void set_num(int num);
void set_num2(int num);
int mcd();
int factorial();
